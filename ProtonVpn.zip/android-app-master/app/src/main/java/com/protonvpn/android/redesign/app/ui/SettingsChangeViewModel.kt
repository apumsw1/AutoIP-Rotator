/*
 * Copyright (c) 2024. Proton AG
 *
 * This file is part of ProtonVPN.
 *
 * ProtonVPN is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ProtonVPN is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ProtonVPN.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.protonvpn.android.redesign.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.protonvpn.android.excludedlocations.usecases.AddExcludedLocation
import com.protonvpn.android.excludedlocations.usecases.RemoveExcludedLocation
import com.protonvpn.android.redesign.settings.ui.NatType
import com.protonvpn.android.redesign.settings.ui.SettingsReconnectHandler
import com.protonvpn.android.redesign.settings.ui.excludedlocations.ExcludedLocationsViewModel.ExcludedLocationUiItem
import com.protonvpn.android.redesign.settings.ui.excludedlocations.toExcludedLocation
import com.protonvpn.android.settings.data.CurrentUserLocalSettingsManager
import com.protonvpn.android.settings.data.SplitTunnelingMode
import com.protonvpn.android.theme.ThemeType
import com.protonvpn.android.userstorage.DontShowAgainStore
import com.protonvpn.android.vpn.ProtocolSelection
import com.protonvpn.android.vpn.VpnUiDelegate
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsChangeViewModel @Inject constructor(
    private val userSettingsManager: CurrentUserLocalSettingsManager,
    private val reconnectHandler: SettingsReconnectHandler,
    private val removeExcludedLocation: RemoveExcludedLocation,
    private val addExcludedLocation: AddExcludedLocation,
) : ViewModel() {

    sealed interface ExcludedLocationEvent {

        data class OnRemoved(val location: ExcludedLocationUiItem.Location) : ExcludedLocationEvent

    }

    val showReconnectDialogFlow = reconnectHandler.showReconnectDialogFlow

    private val _excludedLocationEventsFlow = MutableSharedFlow<ExcludedLocationEvent>(extraBufferCapacity = 1)

    val excludedLocationEventsFlow: SharedFlow<ExcludedLocationEvent> = _excludedLocationEventsFlow.asSharedFlow()

    fun disableCustomDns(uiDelegate: VpnUiDelegate) {
        viewModelScope.launch {
            userSettingsManager.disableCustomDNS()
            reconnectionCheck(uiDelegate, DontShowAgainStore.Type.DnsChangeWhenConnected)
        }
    }

    fun setNetShieldEnabled(isEnabled: Boolean) {
        viewModelScope.launch {
            userSettingsManager.setNetShieldEnabled(isEnabled = isEnabled)
        }
    }

    fun updateProtocol(uiDelegate: VpnUiDelegate, newProtocol: ProtocolSelection) {
        viewModelScope.launch {
            userSettingsManager.update { current ->
                if (current.protocol != newProtocol) viewModelScope.launch {
                    reconnectionCheck(uiDelegate, DontShowAgainStore.Type.ProtocolChangeWhenConnected)
                }
                current.copy(protocol = newProtocol)
            }
        }
    }

    fun setNatType(type: NatType) {
        viewModelScope.launch {
            userSettingsManager.setRandomizedNat(type == NatType.Strict)
        }
    }

    fun setVpnAcceleratorEnabled(isEnabled: Boolean) {
        viewModelScope.launch {
            userSettingsManager.setVpnAcceleratorEnabled(isEnabled = isEnabled)
        }
    }

    fun setAltRoutingEnabled(isEnabled: Boolean) {
        viewModelScope.launch {
            userSettingsManager.setAltRoutingEnabled(isEnabled = isEnabled)
        }
    }

    fun setIPv6Enabled(isEnabled: Boolean, uiDelegate: VpnUiDelegate) {
        viewModelScope.launch {
            userSettingsManager.setIPv6Enabled(isEnabled = isEnabled)
            reconnectionCheck(uiDelegate, DontShowAgainStore.Type.IPv6ChangeWhenConnected)
        }
    }

    fun setLanConnectionsEnabled(isEnabled: Boolean, uiDelegate: VpnUiDelegate) {
        viewModelScope.launch {
            userSettingsManager.setLanConnectionsEnabled(isEnabled = isEnabled)
            reconnectionCheck(uiDelegate, DontShowAgainStore.Type.LanConnectionsChangeWhenConnected)
        }
    }

    fun setLanAllowDirectConnectionsEnabled(isEnabled: Boolean, delegate: VpnUiDelegate) {
        viewModelScope.launch {
            userSettingsManager.setLanAllowDirectConnectionsEnabled(isEnabled = isEnabled)
            reconnectionCheck(delegate, DontShowAgainStore.Type.LanConnectionsChangeWhenConnected)
        }
    }

    fun setSplitTunnelingEnabled(isEnabled: Boolean, uiDelegate: VpnUiDelegate) {
        viewModelScope.launch {
            userSettingsManager.update { current ->
                val oldValue = current.splitTunneling
                val newValue = oldValue.copy(isEnabled = isEnabled)
                if (!oldValue.isEffectivelySameAs(newValue)) viewModelScope.launch {
                    reconnectionCheck(uiDelegate, DontShowAgainStore.Type.SplitTunnelingChangeWhenConnected)
                }
                current.copy(splitTunneling = newValue)
            }
        }
    }

    fun setSplitTunnelingMode(uiDelegate: VpnUiDelegate, newMode: SplitTunnelingMode) {
        viewModelScope.launch {
            userSettingsManager.update { current ->
                val oldValue = current.splitTunneling
                val newValue = oldValue.copy(mode = newMode)
                if (!oldValue.isEffectivelySameAs(newValue)) viewModelScope.launch {
                    reconnectionCheck(uiDelegate, DontShowAgainStore.Type.SplitTunnelingChangeWhenConnected)
                }
                current.copy(splitTunneling = newValue)
            }
        }
    }

    fun onSplitTunnelingUpdated(uiDelegate: VpnUiDelegate) {
        viewModelScope.launch {
            reconnectionCheck(uiDelegate, DontShowAgainStore.Type.SplitTunnelingChangeWhenConnected)
        }
    }

    fun onThemeUpdated(newTheme: ThemeType) {
        viewModelScope.launch { userSettingsManager.update { current -> current.copy(theme = newTheme) } }
    }

    fun onReconnectClicked(uiDelegate: VpnUiDelegate, dontShowAgain: Boolean, type: DontShowAgainStore.Type) =
        reconnectHandler.onReconnectClicked(uiDelegate, dontShowAgain, type)

    fun dismissReconnectDialog(dontShowAgain: Boolean, type: DontShowAgainStore.Type) =
        reconnectHandler.dismissReconnectDialog(dontShowAgain, type)

    fun showDnsReconnectionDialog(uiDelegate: VpnUiDelegate) {
        viewModelScope.launch {
            reconnectionCheck(uiDelegate, DontShowAgainStore.Type.DnsChangeWhenConnected)
        }
    }

    fun onAddExcludedLocation(location: ExcludedLocationUiItem.Location) {
        viewModelScope.launch {
            addExcludedLocation(excludedLocation = location.toExcludedLocation())
        }
    }

    fun onRemoveExcludedLocation(location: ExcludedLocationUiItem.Location) {
        viewModelScope.launch {
            removeExcludedLocation(excludedLocation = location.toExcludedLocation())

            _excludedLocationEventsFlow.emit(value = ExcludedLocationEvent.OnRemoved(location = location))
        }
    }

    fun setNetShieldAdultContentBlockEnabled(isEnabled: Boolean) {
        viewModelScope.launch {
            userSettingsManager.setNetShieldAdultContentBlockEnabled(isEnabled = isEnabled)
        }
    }

    private suspend fun reconnectionCheck(uiDelegate: VpnUiDelegate, type: DontShowAgainStore.Type) =
        reconnectHandler.reconnectionCheck(uiDelegate, type)
}
