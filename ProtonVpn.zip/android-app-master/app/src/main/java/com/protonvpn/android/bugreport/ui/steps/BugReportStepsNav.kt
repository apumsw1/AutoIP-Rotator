package com.protonvpn.android.bugreport.ui.steps

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.protonvpn.android.base.ui.nav.VpnNavHostController
import com.protonvpn.android.base.ui.nav.rememberVpnNavHostController
import com.protonvpn.android.models.config.bugreport.Category
import com.protonvpn.android.models.config.bugreport.InputField
import com.protonvpn.android.base.ui.nav.BaseNav
import com.protonvpn.android.bugreport.ui.BugReportViewModel
import com.protonvpn.android.bugreport.ui.BugReportViewModel.BugReportFormState
import com.protonvpn.android.bugreport.ui.steps.form.BugReportFormScreen
import com.protonvpn.android.bugreport.ui.steps.form.BugReportFormScreen.bugReportFormScreen
import com.protonvpn.android.bugreport.ui.steps.menu.BugReportMenuScreen
import com.protonvpn.android.bugreport.ui.steps.menu.BugReportMenuScreen.bugReportMenuScreen
import com.protonvpn.android.bugreport.ui.steps.suggestions.BugReportSuggestionsScreen
import com.protonvpn.android.bugreport.ui.steps.suggestions.BugReportSuggestionsScreen.bugReportSuggestionsScreen

class BugReportStepsNav(
    selfNav: VpnNavHostController,
) : BaseNav<BugReportStepsNav>(selfNav, "bugReportSteps") {

    @Composable
    fun NavHost(
        viewState: BugReportViewModel.ViewState,
        formState: BugReportFormState,
        onUpdateApp: suspend () -> Unit,
        onOpenLink: (String) -> Unit,
        onSelectCategory: (Category) -> Unit,
        onSetCurrentStep: (BugReportViewModel.BugReportSteps) -> Unit,
        onFormEmailChanged: (String) -> Unit,
        onFormFieldChanged: (InputField, String) -> Unit,
        onFormSendLogsChanged: (Boolean) -> Unit,
        modifier: Modifier = Modifier,
    ) {
        SafeNavHost(
            modifier = modifier,
            startScreen = BugReportMenuScreen,
        ) {
            bugReportMenuScreen(
                viewState = viewState,
                onUpdateApp = onUpdateApp,
                onSetCurrentStep = onSetCurrentStep,
                onCategorySelected = { selectedCategory ->
                    onSelectCategory(selectedCategory)

                    if (selectedCategory.suggestions.isEmpty()) {
                        navigateInternal(screen = BugReportFormScreen)
                    } else {
                        navigateInternal(screen = BugReportSuggestionsScreen)
                    }
                },
            )

            bugReportSuggestionsScreen(
                viewState = viewState,
                onSetCurrentStep = onSetCurrentStep,
                onOpenLink = onOpenLink,
            )

            bugReportFormScreen(
                viewState = viewState,
                formState = formState,
                onSetCurrentStep = onSetCurrentStep,
                onFormEmailChanged = onFormEmailChanged,
                onFormFieldChanged = onFormFieldChanged,
                onFormSendLogsChanged = onFormSendLogsChanged,
            )
        }
    }

}

@Composable
fun rememberBugReportStepsNav(
    selfNavController: VpnNavHostController = rememberVpnNavHostController(),
) = remember(key1 = selfNavController) {
    BugReportStepsNav(
        selfNav = selfNavController,
    )
}
