dependencies = [
  {
    "project": "Accompanist Drawable Painter library",
    "description": "Utilities for Jetpack Compose",
    "version": "0.30.1",
    "developers": [
      "Google"
    ],
    "url": "https://github.com/google/accompanist/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.accompanist:accompanist-drawablepainter:0.30.1"
  },
  {
    "project": "Accompanist Permissions",
    "description": "Utilities for Jetpack Compose",
    "version": "0.37.2",
    "developers": [
      "Google"
    ],
    "url": "https://github.com/google/accompanist/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.accompanist:accompanist-permissions:0.37.2"
  },
  {
    "project": "account",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account:36.6.1"
  },
  {
    "project": "account-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-dagger:36.6.1"
  },
  {
    "project": "account-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-data:36.6.1"
  },
  {
    "project": "account-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-domain:36.6.1"
  },
  {
    "project": "account-manager-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-manager-data:36.6.1"
  },
  {
    "project": "account-manager-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-manager-domain:36.6.1"
  },
  {
    "project": "account-manager-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-manager-presentation:36.6.1"
  },
  {
    "project": "account-manager-presentation-compose",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-manager-presentation-compose:36.6.1"
  },
  {
    "project": "account-recovery",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-recovery:36.6.1"
  },
  {
    "project": "account-recovery-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-recovery-dagger:36.6.1"
  },
  {
    "project": "account-recovery-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-recovery-data:36.6.1"
  },
  {
    "project": "account-recovery-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-recovery-domain:36.6.1"
  },
  {
    "project": "account-recovery-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-recovery-presentation:36.6.1"
  },
  {
    "project": "account-recovery-presentation-compose",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:account-recovery-presentation-compose:36.6.1"
  },
  {
    "project": "Activity",
    "description": "Provides the base Activity subclass and the relevant hooks to build a composable structure on top.",
    "version": "1.12.4",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/activity#1.12.4",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.activity:activity:1.12.4"
  },
  {
    "project": "Activity Compose",
    "description": "Compose integration with Activity",
    "version": "1.12.4",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/activity#1.12.4",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.activity:activity-compose:1.12.4"
  },
  {
    "project": "Activity Kotlin Extensions",
    "description": "Kotlin extensions for \u0027activity\u0027 artifact",
    "version": "1.12.4",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/activity#1.12.4",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.activity:activity-ktx:1.12.4"
  },
  {
    "project": "AES-Crypto",
    "description": "A simple Android class for encrypting \u0026 decrypting strings, aiming to avoid the classic mistakes that most such classes suffer from.",
    "version": "0.0.5",
    "developers": [
      "Scott Alexander-Bown"
    ],
    "url": "https://github.com/scottyab/java-aes-crypto.git",
    "year": null,
    "licenses": [
      {
        "license": "MIT license",
        "license_url": "https://github.com/scottyab/java-aes-crypto/blob/master/LICENSE"
      }
    ],
    "dependency": "com.scottyab:aes-crypto:0.0.5"
  },
  {
    "project": "Android App Startup Runtime",
    "description": "Android App Startup Runtime",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/startup#1.1.1",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.startup:startup-runtime:1.1.1"
  },
  {
    "project": "Android Arch-Common",
    "description": "Android Arch-Common",
    "version": "2.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/arch-core#2.2.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.arch.core:core-common:2.2.0"
  },
  {
    "project": "Android Arch-Runtime",
    "description": "Android Arch-Runtime",
    "version": "2.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/arch-core#2.2.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.arch.core:core-runtime:2.2.0"
  },
  {
    "project": "Android Graphics Path",
    "description": "Query segment data for android.graphics.Path objects",
    "version": "1.0.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/graphics#1.0.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.graphics:graphics-path:1.0.1"
  },
  {
    "project": "Android Preferences KTX",
    "description": "Kotlin extensions for preferences",
    "version": "1.2.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/preference#1.2.1",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.preference:preference-ktx:1.2.1"
  },
  {
    "project": "Android Resource Inspection - Annotations",
    "description": "Annotation processors for Android resource and layout inspection",
    "version": "1.0.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/resourceinspection#1.0.1",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.resourceinspection:resourceinspection-annotation:1.0.1"
  },
  {
    "project": "Android Support AnimatedVectorDrawable",
    "description": "Android Support AnimatedVectorDrawable",
    "version": "1.1.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx",
    "year": "2015",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.vectordrawable:vectordrawable-animated:1.1.0"
  },
  {
    "project": "Android Support CardView v7",
    "description": "Android Support CardView v7",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.cardview:cardview:1.0.0"
  },
  {
    "project": "Android Support DynamicAnimation",
    "description": "Physics-based animation in support library, where the animations are driven by physics force. You can use this Animation library to create smooth and realistic animations.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.dynamicanimation:dynamicanimation:1.0.0"
  },
  {
    "project": "Android Support ExifInterface",
    "description": "Android Support ExifInterface",
    "version": "1.3.6",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/exifinterface#1.3.6",
    "year": "2016",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.exifinterface:exifinterface:1.3.6"
  },
  {
    "project": "Android Support Library Annotations",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2013",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.annotation:annotation:1.0.0"
  },
  {
    "project": "Android Support Library Async Layout Inflater",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.asynclayoutinflater:asynclayoutinflater:1.0.0"
  },
  {
    "project": "Android Support Library Coordinator Layout",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/coordinatorlayout#1.2.0",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.coordinatorlayout:coordinatorlayout:1.2.0"
  },
  {
    "project": "Android Support Library core UI",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.legacy:legacy-support-core-ui:1.0.0"
  },
  {
    "project": "Android Support Library core utils",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.legacy:legacy-support-core-utils:1.0.0"
  },
  {
    "project": "Android Support Library Cursor Adapter",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.cursoradapter:cursoradapter:1.0.0"
  },
  {
    "project": "Android Support Library Custom View",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.1.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.customview:customview:1.1.0"
  },
  {
    "project": "Android Support Library Custom View",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.swiperefreshlayout:swiperefreshlayout:1.0.0"
  },
  {
    "project": "Android Support Library Document File",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.documentfile:documentfile:1.0.0"
  },
  {
    "project": "Android Support Library Drawer Layout",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.drawerlayout:drawerlayout:1.1.1"
  },
  {
    "project": "Android Support Library Interpolators",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.interpolator:interpolator:1.0.0"
  },
  {
    "project": "Android Support Library loader",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.loader:loader:1.0.0"
  },
  {
    "project": "Android Support Library Local Broadcast Manager",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.localbroadcastmanager:localbroadcastmanager:1.0.0"
  },
  {
    "project": "Android Support Library media compat",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.media:media:1.0.0"
  },
  {
    "project": "Android Support Library Print",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.print:print:1.0.0"
  },
  {
    "project": "Android Support Library Sliding Pane Layout",
    "description": "SlidingPaneLayout offers a responsive, two pane layout that automatically switches between overlapping panes on smaller devices to a side by side view on larger devices.",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/slidingpanelayout#1.2.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.slidingpanelayout:slidingpanelayout:1.2.0"
  },
  {
    "project": "Android Support Library v4",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.legacy:legacy-support-v4:1.0.0"
  },
  {
    "project": "Android Support Library View Pager",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.viewpager:viewpager:1.0.0"
  },
  {
    "project": "Android Support RecyclerView",
    "description": "Android Support RecyclerView",
    "version": "1.3.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/recyclerview#1.3.2",
    "year": "2014",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.recyclerview:recyclerview:1.3.2"
  },
  {
    "project": "Android Tracing",
    "description": "Android Tracing",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/tracing#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.tracing:tracing:1.2.0"
  },
  {
    "project": "AndroidSVG",
    "description": "SVG rendering library for Android.",
    "version": "1.4",
    "developers": [
      "Paul LeBeau"
    ],
    "url": "https://github.com/BigBadaboom/androidsvg",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.caverock:androidsvg-aar:1.4"
  },
  {
    "project": "AndroidX Autofill",
    "description": "AndroidX Autofill",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.autofill:autofill:1.0.0"
  },
  {
    "project": "AndroidX Futures",
    "description": "Androidx implementation of Guava\u0027s ListenableFuture",
    "version": "1.1.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/topic/libraries/architecture/index.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.concurrent:concurrent-futures:1.1.0"
  },
  {
    "project": "AndroidX Futures Kotlin Extensions",
    "description": "Kotlin Extensions for Androidx implementation of Guava\u0027s ListenableFuture",
    "version": "1.1.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/topic/libraries/architecture/index.html",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.concurrent:concurrent-futures-ktx:1.1.0"
  },
  {
    "project": "AndroidX Preference",
    "description": "AndroidX Preference",
    "version": "1.2.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/preference#1.2.1",
    "year": "2015",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.preference:preference:1.2.1"
  },
  {
    "project": "AndroidX Test Library",
    "description": "The AndroidX Test Library provides an extensive framework for testing Android apps",
    "version": "3.7.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/testing",
    "year": "2015",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.test.espresso:espresso-idling-resource:3.7.0"
  },
  {
    "project": "androidx.core:core-viewtree",
    "description": "Provides ViewTree extensions packaged for use by other core androidx libraries",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/core#1.0.0",
    "year": "2024",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.core:core-viewtree:1.0.0"
  },
  {
    "project": "androidx.customview:poolingcontainer",
    "description": "Utilities for listening to the lifecycle of containers that manage their child Views\u0027 lifecycle, such as RecyclerView",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/customview#1.0.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.customview:customview-poolingcontainer:1.0.0"
  },
  {
    "project": "Annotation",
    "description": "Provides source annotations for tooling and readability.",
    "version": "1.9.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/annotation#1.9.1",
    "year": "2013",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.annotation:annotation-jvm:1.9.1"
  },
  {
    "project": "Apache Commons Codec",
    "description": "The Apache Commons Codec package contains simple encoder and decoders for\n     various formats such as Base64 and Hexadecimal.  In addition to these\n     widely used encoders and decoders, the codec package also maintains a\n     collection of phonetic encoding utilities.",
    "version": "1.15",
    "developers": [
      "Henri Yandell",
      "Tim OBrien",
      "Scott Sanders",
      "Rodney Waldhoff",
      "Daniel Rall",
      "Jon S. Stevens",
      "Gary Gregory",
      "David Graham",
      "Julius Davies",
      "Thomas Neidhart",
      "Rob Tompkins"
    ],
    "url": "https://commons.apache.org/proper/commons-codec/",
    "year": "2002",
    "licenses": [
      {
        "license": "Apache License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "commons-codec:commons-codec:1.15"
  },
  {
    "project": "app-update",
    "description": null,
    "version": "2.1.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Play Core Software Development Kit Terms of Service",
        "license_url": "https://developer.android.com/guide/playcore/license"
      }
    ],
    "dependency": "com.google.android.play:app-update:2.1.0"
  },
  {
    "project": "app-update-ktx",
    "description": null,
    "version": "2.1.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Play Core Software Development Kit Terms of Service",
        "license_url": "https://developer.android.com/guide/playcore/license"
      }
    ],
    "dependency": "com.google.android.play:app-update-ktx:2.1.0"
  },
  {
    "project": "AppCompat",
    "description": "Provides backwards-compatible implementations of UI-related Android SDK functionality, including dark mode and Material theming.",
    "version": "1.7.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/appcompat#1.7.0",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.appcompat:appcompat:1.7.0"
  },
  {
    "project": "AppCompat Resources",
    "description": "Provides backward-compatible implementations of resource-related Android SDKfunctionality, including color state list theming.",
    "version": "1.7.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/appcompat#1.7.0",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.appcompat:appcompat-resources:1.7.0"
  },
  {
    "project": "atomicfu",
    "description": "AtomicFU utilities",
    "version": "0.23.2",
    "developers": [
      "JetBrains Team"
    ],
    "url": "https://github.com/Kotlin/kotlinx.atomicfu",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlinx:atomicfu-jvm:0.23.2"
  },
  {
    "project": "auth",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth:36.6.1"
  },
  {
    "project": "auth-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth-dagger:36.6.1"
  },
  {
    "project": "auth-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth-data:36.6.1"
  },
  {
    "project": "auth-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth-domain:36.6.1"
  },
  {
    "project": "auth-fido-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth-fido-dagger:36.6.1"
  },
  {
    "project": "auth-fido-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth-fido-domain:36.6.1"
  },
  {
    "project": "auth-fido-play",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth-fido-play:36.6.1"
  },
  {
    "project": "auth-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth-presentation:36.6.1"
  },
  {
    "project": "auth-presentation-compose",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:auth-presentation-compose:36.6.1"
  },
  {
    "project": "Base32 Encoding",
    "description": "Base32 Encoding",
    "version": "2.3.1",
    "developers": [
      "Matthew Nelson"
    ],
    "url": "https://github.com/05nelsonm/encoding/",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "io.matthewnelson.encoding:base32-jvm:2.3.1"
  },
  {
    "project": "billing",
    "description": null,
    "version": "7.1.1",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.android.billingclient:billing:7.1.1"
  },
  {
    "project": "billing-ktx",
    "description": null,
    "version": "7.1.1",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.android.billingclient:billing-ktx:7.1.1"
  },
  {
    "project": "Biometric",
    "description": "The Biometric library is a static library that you can add to your Android application. It invokes BiometricPrompt on devices running P and greater, and on older devices will show a compat dialog. Compatible on devices running API 14 or later.",
    "version": "1.2.0-alpha05",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/biometric#1.2.0-alpha05",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.biometric:biometric:1.2.0-alpha05"
  },
  {
    "project": "biometric",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:biometric:36.6.1"
  },
  {
    "project": "biometric-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:biometric-dagger:36.6.1"
  },
  {
    "project": "biometric-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:biometric-data:36.6.1"
  },
  {
    "project": "biometric-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:biometric-domain:36.6.1"
  },
  {
    "project": "biometric-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:biometric-presentation:36.6.1"
  },
  {
    "project": "Browser",
    "description": "Provides support for embedding Custom Tabs in an app.",
    "version": "1.9.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/browser#1.9.0",
    "year": "2015",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.browser:browser:1.9.0"
  },
  {
    "project": "cache4k",
    "description": "In-memory Cache for Kotlin Multiplatform",
    "version": "0.13.0",
    "developers": [
      "Reactive Circus"
    ],
    "url": "https://github.com/reactivecircus/cache4k",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "io.github.reactivecircus.cache4k:cache4k-jvm:0.13.0"
  },
  {
    "project": "challenge",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:challenge:36.6.1"
  },
  {
    "project": "challenge-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:challenge-dagger:36.6.1"
  },
  {
    "project": "challenge-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:challenge-data:36.6.1"
  },
  {
    "project": "challenge-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:challenge-domain:36.6.1"
  },
  {
    "project": "challenge-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:challenge-presentation:36.6.1"
  },
  {
    "project": "challenge-presentation-compose",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:challenge-presentation-compose:36.6.1"
  },
  {
    "project": "CircleIndicator",
    "description": "A lightweight indicator",
    "version": "2.1.6",
    "developers": [
      "Relex"
    ],
    "url": "https://github.com/ongakuer/CircleIndicator",
    "year": null,
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "me.relex:circleindicator:2.1.6"
  },
  {
    "project": "coil",
    "description": "An image loading library for Android backed by Kotlin Coroutines.",
    "version": "2.4.0",
    "developers": [
      "Coil Contributors"
    ],
    "url": "https://github.com/coil-kt/coil",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "io.coil-kt:coil:2.4.0"
  },
  {
    "project": "coil-base",
    "description": "An image loading library for Android backed by Kotlin Coroutines.",
    "version": "2.4.0",
    "developers": [
      "Coil Contributors"
    ],
    "url": "https://github.com/coil-kt/coil",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "io.coil-kt:coil-base:2.4.0"
  },
  {
    "project": "coil-compose",
    "description": "An image loading library for Android backed by Kotlin Coroutines.",
    "version": "2.4.0",
    "developers": [
      "Coil Contributors"
    ],
    "url": "https://github.com/coil-kt/coil",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "io.coil-kt:coil-compose:2.4.0"
  },
  {
    "project": "coil-compose-base",
    "description": "An image loading library for Android backed by Kotlin Coroutines.",
    "version": "2.4.0",
    "developers": [
      "Coil Contributors"
    ],
    "url": "https://github.com/coil-kt/coil",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "io.coil-kt:coil-compose-base:2.4.0"
  },
  {
    "project": "coil-svg",
    "description": "An image loading library for Android backed by Kotlin Coroutines.",
    "version": "2.4.0",
    "developers": [
      "Coil Contributors"
    ],
    "url": "https://github.com/coil-kt/coil",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "io.coil-kt:coil-svg:2.4.0"
  },
  {
    "project": "collections",
    "description": "Standalone efficient collections.",
    "version": "1.5.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/collection#1.5.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.collection:collection-jvm:1.5.0"
  },
  {
    "project": "Collections Kotlin Extensions",
    "description": "Kotlin extensions for \u0027collection\u0027 artifact",
    "version": "1.5.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/collection#1.5.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.collection:collection-ktx:1.5.0"
  },
  {
    "project": "Compose Animation",
    "description": "Compose animation library",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-animation#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.animation:animation-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Animation",
    "description": "Compose animation library",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-animation#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.animation:animation-android:1.10.3"
  },
  {
    "project": "Compose Animation",
    "description": "Compose animation library",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.animation:animation-desktop:1.7.0"
  },
  {
    "project": "Compose Animation Core",
    "description": "Animation engine and animation primitives that are the building blocks of the Compose animation library",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.animation:animation-core-desktop:1.7.0"
  },
  {
    "project": "Compose Animation Core",
    "description": "Animation engine and animation primitives that are the building blocks of the Compose animation library",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-animation#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.animation:animation-core-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Animation Core",
    "description": "Animation engine and animation primitives that are the building blocks of the Compose animation library",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-animation#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.animation:animation-core-android:1.10.3"
  },
  {
    "project": "Compose Foundation",
    "description": "Higher level abstractions of the Compose UI primitives. This library is design system agnostic, providing the high-level building blocks for both application and design-system developers",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-foundation#1.10.3",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.foundation:foundation-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Foundation",
    "description": "Higher level abstractions of the Compose UI primitives. This library is design system agnostic, providing the high-level building blocks for both application and design-system developers",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.foundation:foundation-desktop:1.7.0"
  },
  {
    "project": "Compose Foundation",
    "description": "Higher level abstractions of the Compose UI primitives. This library is design system agnostic, providing the high-level building blocks for both application and design-system developers",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-foundation#1.10.3",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.foundation:foundation-android:1.10.3"
  },
  {
    "project": "Compose Geometry",
    "description": "Compose classes related to dimensions without units",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.ui:ui-geometry-desktop:1.7.0"
  },
  {
    "project": "Compose Geometry",
    "description": "Compose classes related to dimensions without units",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-geometry-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Geometry",
    "description": "Compose classes related to dimensions without units",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-geometry-android:1.10.3"
  },
  {
    "project": "Compose Graphics",
    "description": "Compose graphics",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-graphics-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Graphics",
    "description": "Compose graphics",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.ui:ui-graphics-desktop:1.7.0"
  },
  {
    "project": "Compose Graphics",
    "description": "Compose graphics",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-graphics-android:1.10.3"
  },
  {
    "project": "Compose Layouts",
    "description": "Compose layout implementations",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.foundation:foundation-layout-desktop:1.7.0"
  },
  {
    "project": "Compose Layouts",
    "description": "Compose layout implementations",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-foundation#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.foundation:foundation-layout-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Layouts",
    "description": "Compose layout implementations",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-foundation#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.foundation:foundation-layout-android:1.10.3"
  },
  {
    "project": "Compose LiveData integration",
    "description": "Compose integration with LiveData",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-livedata:1.10.3"
  },
  {
    "project": "Compose Material 3 Window Size Class",
    "description": "Provides window size classes for building responsive UIs",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material3#1.4.0",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material3:material3-window-size-class-jvmstubs:1.4.0"
  },
  {
    "project": "Compose Material 3 Window Size Class",
    "description": "Provides window size classes for building responsive UIs",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material3#1.4.0",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material3:material3-window-size-class-android:1.4.0"
  },
  {
    "project": "Compose Material Components",
    "description": "Compose Material Design Components library",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material#1.10.3",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material:material-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Material Components",
    "description": "Compose Material Design Components library",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material#1.10.3",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material:material-android:1.10.3"
  },
  {
    "project": "Compose Material Icons Core",
    "description": "Compose Material Design core icons. This module contains the most commonly used set of Material icons.",
    "version": "1.7.8",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material#1.7.8",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material:material-icons-core-desktop:1.7.8"
  },
  {
    "project": "Compose Material Icons Core",
    "description": "Compose Material Design core icons. This module contains the most commonly used set of Material icons.",
    "version": "1.7.8",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material#1.7.8",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material:material-icons-core-android:1.7.8"
  },
  {
    "project": "Compose Material Ripple",
    "description": "Material ripple used to build interactive components",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material:material-ripple-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Material Ripple",
    "description": "Material ripple used to build interactive components",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material:material-ripple-android:1.10.3"
  },
  {
    "project": "Compose Material3 Components",
    "description": "Compose Material You Design Components library",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material3#1.4.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material3:material3-jvmstubs:1.4.0"
  },
  {
    "project": "Compose Material3 Components",
    "description": "Compose Material You Design Components library",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-material3#1.4.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.material3:material3-android:1.4.0"
  },
  {
    "project": "Compose Navigation",
    "description": "Compose integration with Navigation",
    "version": "2.9.7",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigation#2.9.7",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigation:navigation-compose-jvmstubs:2.9.7"
  },
  {
    "project": "Compose Navigation",
    "description": "Compose integration with Navigation",
    "version": "2.9.7",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigation#2.9.7",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigation:navigation-compose-android:2.9.7"
  },
  {
    "project": "Compose Runtime",
    "description": "Tree composition support for code generated by the Compose compiler plugin and corresponding public API",
    "version": "1.9.2",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.runtime:runtime-desktop:1.9.2"
  },
  {
    "project": "Compose Runtime",
    "description": "Tree composition support for code generated by the Compose compiler plugin and corresponding public API",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-desktop:1.10.3"
  },
  {
    "project": "Compose Runtime",
    "description": "Tree composition support for code generated by the Compose compiler plugin and corresponding public API",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-android:1.10.3"
  },
  {
    "project": "Compose Runtime Annotation",
    "description": "Provides Compose-specific annotations used by the compiler and tooling",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2025",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-annotation-jvm:1.10.3"
  },
  {
    "project": "Compose Runtime Annotation",
    "description": "Provides Compose-specific annotations used by the compiler and tooling",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2025",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-annotation-android:1.10.3"
  },
  {
    "project": "Compose Runtime Retain",
    "description": "Preserve state in composable methods across configuration changes and other transient content destruction scenarios",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2025",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-retain-desktop:1.10.3"
  },
  {
    "project": "Compose Runtime Retain",
    "description": "Preserve state in composable methods across configuration changes and other transient content destruction scenarios",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2025",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-retain-android:1.10.3"
  },
  {
    "project": "Compose Saveable",
    "description": "Compose components that allow saving and restoring the local ui state",
    "version": "1.9.2",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.runtime:runtime-saveable-desktop:1.9.2"
  },
  {
    "project": "Compose Saveable",
    "description": "Compose components that allow saving and restoring the local ui state",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-saveable-desktop:1.10.3"
  },
  {
    "project": "Compose Saveable",
    "description": "Compose components that allow saving and restoring the local ui state",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-runtime#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.runtime:runtime-saveable-android:1.10.3"
  },
  {
    "project": "Compose UI",
    "description": "Compose UI primitives. This library contains the primitives that form the Compose UI Toolkit, such as drawing, measurement and layout.",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-jvmstubs:1.10.3"
  },
  {
    "project": "Compose UI",
    "description": "Compose UI primitives. This library contains the primitives that form the Compose UI Toolkit, such as drawing, measurement and layout.",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-android:1.10.3"
  },
  {
    "project": "Compose UI Preview Tooling",
    "description": "Compose tooling library API. This library provides the API required to declare @Preview composables in user apps.",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-tooling-preview-jvmstubs:1.10.3"
  },
  {
    "project": "Compose UI Preview Tooling",
    "description": "Compose tooling library API. This library provides the API required to declare @Preview composables in user apps.",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-tooling-preview-android:1.10.3"
  },
  {
    "project": "Compose UI primitives",
    "description": "Compose UI primitives. This library contains the primitives that form the Compose UI Toolkit, such as drawing, measurement and layout.",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.ui:ui-desktop:1.7.0"
  },
  {
    "project": "Compose UI Text",
    "description": "Compose Text primitives and utilities",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-text-jvmstubs:1.10.3"
  },
  {
    "project": "Compose UI Text",
    "description": "Compose Text primitives and utilities",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.ui:ui-text-desktop:1.7.0"
  },
  {
    "project": "Compose UI Text",
    "description": "Compose Text primitives and utilities",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-text-android:1.10.3"
  },
  {
    "project": "Compose Unit",
    "description": "Compose classes for simple units",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-unit-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Unit",
    "description": "Compose classes for simple units",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.ui:ui-unit-desktop:1.7.0"
  },
  {
    "project": "Compose Unit",
    "description": "Compose classes for simple units",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-unit-android:1.10.3"
  },
  {
    "project": "Compose Util",
    "description": "Internal Compose utilities used by other modules",
    "version": "1.7.0",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.compose.ui:ui-util-desktop:1.7.0"
  },
  {
    "project": "Compose Util",
    "description": "Internal Compose utilities used by other modules",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-util-jvmstubs:1.10.3"
  },
  {
    "project": "Compose Util",
    "description": "Internal Compose utilities used by other modules",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-util-android:1.10.3"
  },
  {
    "project": "Compose ViewBinding",
    "description": "Compose integration with ViewBinding",
    "version": "1.10.3",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/compose-ui#1.10.3",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.compose.ui:ui-viewbinding:1.10.3"
  },
  {
    "project": "configuration",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:configuration:36.6.1"
  },
  {
    "project": "configuration-dagger-staticdefaults",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:configuration-dagger-staticdefaults:36.6.1"
  },
  {
    "project": "configuration-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:configuration-data:36.6.1"
  },
  {
    "project": "ConstraintLayout",
    "description": "This library offers a flexible and adaptable way to position and animate widgets",
    "version": "2.2.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/constraintlayout#2.2.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.constraintlayout:constraintlayout:2.2.1"
  },
  {
    "project": "ConstraintLayout Compose",
    "description": "This library offers a flexible and adaptable way to position and animate widgets in Compose",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/constraintlayout#1.1.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.constraintlayout:constraintlayout-compose-android:1.1.1"
  },
  {
    "project": "ConstraintLayout Core",
    "description": "This library contains engines and algorithms for constraint based layout and complex animations (it is used by the ConstraintLayout library)",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/constraintlayout#1.1.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.constraintlayout:constraintlayout-core:1.1.1"
  },
  {
    "project": "Core",
    "description": "Provides backward-compatible implementations of Android platform APIs and features.",
    "version": "1.17.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/core#1.17.0",
    "year": "2015",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.core:core:1.17.0"
  },
  {
    "project": "Core Encoding Abstractions",
    "description": "Core Encoding Abstractions",
    "version": "2.3.1",
    "developers": [
      "Matthew Nelson"
    ],
    "url": "https://github.com/05nelsonm/encoding/",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "io.matthewnelson.encoding:core-jvm:2.3.1"
  },
  {
    "project": "Core Kotlin Extensions",
    "description": "Kotlin extensions for \u0027core\u0027 artifact",
    "version": "1.17.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/core#1.17.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.core:core-ktx:1.17.0"
  },
  {
    "project": "core-common",
    "description": null,
    "version": "2.0.4",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Play Core Software Development Kit Terms of Service",
        "license_url": "https://developer.android.com/guide/playcore/license"
      }
    ],
    "dependency": "com.google.android.play:core-common:2.0.4"
  },
  {
    "project": "country",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:country:36.6.1"
  },
  {
    "project": "country-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:country-dagger:36.6.1"
  },
  {
    "project": "country-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:country-data:36.6.1"
  },
  {
    "project": "country-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:country-domain:36.6.1"
  },
  {
    "project": "country-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:country-presentation:36.6.1"
  },
  {
    "project": "crypto",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto:36.6.1"
  },
  {
    "project": "crypto-android",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto-android:36.6.1"
  },
  {
    "project": "crypto-common",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto-common:36.6.1"
  },
  {
    "project": "crypto-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto-dagger:36.6.1"
  },
  {
    "project": "crypto-validator",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto-validator:36.6.1"
  },
  {
    "project": "crypto-validator-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto-validator-dagger:36.6.1"
  },
  {
    "project": "crypto-validator-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto-validator-data:36.6.1"
  },
  {
    "project": "crypto-validator-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto-validator-domain:36.6.1"
  },
  {
    "project": "crypto-validator-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:crypto-validator-presentation:36.6.1"
  },
  {
    "project": "Dagger",
    "description": "A fast dependency injector for Android and Java.",
    "version": "2.58",
    "developers": [
      ""
    ],
    "url": "https://github.com/google/dagger",
    "year": null,
    "licenses": [
      {
        "license": "Apache 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.dagger:dagger:2.58"
  },
  {
    "project": "Dagger Lint Rules AAR Distribution",
    "description": "A fast dependency injector for Android and Java.",
    "version": "2.58",
    "developers": [
      ""
    ],
    "url": "https://github.com/google/dagger",
    "year": null,
    "licenses": [
      {
        "license": "Apache 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.dagger:dagger-lint-aar:2.58"
  },
  {
    "project": "data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:data:36.6.1"
  },
  {
    "project": "data-room",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:data-room:36.6.1"
  },
  {
    "project": "DataStore",
    "description": "Android DataStore - contains the underlying store used by each serialization method along with components that require an Android dependency",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-jvm:1.2.0"
  },
  {
    "project": "DataStore",
    "description": "Android DataStore - contains the underlying store used by each serialization method along with components that require an Android dependency",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-android:1.2.0"
  },
  {
    "project": "DataStore Core",
    "description": "Android DataStore Core - contains the underlying store used by each serialization method",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-core-jvm:1.2.0"
  },
  {
    "project": "DataStore Core",
    "description": "Android DataStore Core - contains the underlying store used by each serialization method",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-core-android:1.2.0"
  },
  {
    "project": "DataStore Core Okio",
    "description": "Android DataStore Core Okio- contains APIs to use datastore-core in multiplatform via okio",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-core-okio-jvm:1.2.0"
  },
  {
    "project": "device-migration",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:device-migration:36.6.1"
  },
  {
    "project": "device-migration-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:device-migration-dagger:36.6.1"
  },
  {
    "project": "device-migration-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:device-migration-data:36.6.1"
  },
  {
    "project": "device-migration-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:device-migration-domain:36.6.1"
  },
  {
    "project": "device-migration-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:device-migration-presentation:36.6.1"
  },
  {
    "project": "dnsjava",
    "description": "dnsjava is an implementation of DNS in Java. It supports all defined record types (including the DNSSEC\n        types), and unknown types. It can be used for queries, zone transfers, and dynamic updates. It includes a cache\n        which can be used by clients, and a minimal implementation of a server. It supports TSIG authenticated messages,\n        partial DNSSEC verification, and EDNS0.",
    "version": "3.6.2",
    "developers": [
      "Brian Wellington",
      "Ingo Bauersachs"
    ],
    "url": "https://github.com/dnsjava/dnsjava",
    "year": null,
    "licenses": [
      {
        "license": "BSD-3-Clause",
        "license_url": "https://opensource.org/licenses/BSD-3-Clause"
      }
    ],
    "dependency": "dnsjava:dnsjava:3.6.2"
  },
  {
    "project": "domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:domain:36.6.1"
  },
  {
    "project": "Emoji2",
    "description": "Core library to enable emoji compatibility in Kitkat and newer devices to avoid the empty emoji characters.",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/emoji2#1.4.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.emoji2:emoji2:1.4.0"
  },
  {
    "project": "Emoji2 Views Helper",
    "description": "Provide helper classes for Emoji2 views.",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/emoji2#1.4.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.emoji2:emoji2-views-helper:1.4.0"
  },
  {
    "project": "error-prone annotations",
    "description": null,
    "version": "2.15.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Apache 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.errorprone:error_prone_annotations:2.15.0"
  },
  {
    "project": "event-manager",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:event-manager:36.6.1"
  },
  {
    "project": "event-manager-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:event-manager-dagger:36.6.1"
  },
  {
    "project": "event-manager-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:event-manager-data:36.6.1"
  },
  {
    "project": "event-manager-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:event-manager-domain:36.6.1"
  },
  {
    "project": "Experimental annotation",
    "description": "Java annotation for use on unstable Android API surfaces. When used in conjunction with the Experimental annotation lint checks, this annotation provides functional parity with Kotlin\u0027s Experimental annotation.",
    "version": "1.4.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/annotation#1.4.1",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.annotation:annotation-experimental:1.4.1"
  },
  {
    "project": "feature-flag",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:feature-flag:36.6.1"
  },
  {
    "project": "feature-flag-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:feature-flag-dagger:36.6.1"
  },
  {
    "project": "feature-flag-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:feature-flag-data:36.6.1"
  },
  {
    "project": "feature-flag-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:feature-flag-domain:36.6.1"
  },
  {
    "project": "FindBugs-jsr305",
    "description": "JSR305 Annotations for Findbugs",
    "version": "3.0.2",
    "developers": [],
    "url": "http://findbugs.sourceforge.net/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.code.findbugs:jsr305:3.0.2"
  },
  {
    "project": "firebase-encoders",
    "description": null,
    "version": "17.0.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.firebase:firebase-encoders:17.0.0"
  },
  {
    "project": "firebase-encoders-json",
    "description": null,
    "version": "18.0.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.firebase:firebase-encoders-json:18.0.0"
  },
  {
    "project": "firebase-encoders-proto",
    "description": null,
    "version": "16.0.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.firebase:firebase-encoders-proto:16.0.0"
  },
  {
    "project": "flexbox-layout",
    "description": "Flexbox for Android",
    "version": "3.0.0",
    "developers": [
      "Google"
    ],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.android.flexbox:flexbox:3.0.0"
  },
  {
    "project": "fragment",
    "description": "The Support Library is a static library that you can add to your Android application in order to use APIs that are either not available for older platform versions or utility APIs that aren\u0027t a part of the framework APIs. Compatible on devices running API 14 or later.",
    "version": "1.8.9",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/fragment#1.8.9",
    "year": "2011",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.fragment:fragment:1.8.9"
  },
  {
    "project": "Fragment Compose",
    "description": "Integrate Fragments with Compose to provide helper APIs for using Fragments inCompose or Compose inside of Fragments",
    "version": "1.8.9",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/fragment#1.8.9",
    "year": "2024",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.fragment:fragment-compose:1.8.9"
  },
  {
    "project": "Fragment Kotlin Extensions",
    "description": "Kotlin extensions for \u0027fragment\u0027 artifact",
    "version": "1.8.9",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/fragment#1.8.9",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.fragment:fragment-ktx:1.8.9"
  },
  {
    "project": "Glance",
    "description": "Glance allows developers to build layouts for remote surfaces using a Jetpack Compose-style API.",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/glance#1.1.1",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.glance:glance:1.1.1"
  },
  {
    "project": "Glance AppWidget External Protobuf",
    "description": "Repackaged proto-lite dependency for use by galnce",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/glance#1.1.1",
    "year": "2024",
    "licenses": [
      {
        "license": "BSD-3-Clause",
        "license_url": "https://opensource.org/licenses/BSD-3-Clause"
      }
    ],
    "dependency": "androidx.glance:glance-appwidget-external-protobuf:1.1.1"
  },
  {
    "project": "Glance AppWidget Preview",
    "description": "Glance tooling library. This library provides the API required for the GlanceAppWidget components and its Glance @Composable to be previewable in the IDE.",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/glance#1.1.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.glance:glance-appwidget-preview:1.1.1"
  },
  {
    "project": "Glance AppWidget Protos",
    "description": "Protos for use with glance app widgets.",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/glance#1.1.1",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.glance:glance-appwidget-proto:1.1.1"
  },
  {
    "project": "Glance For App Widgets",
    "description": "Glance-appwidgets allows developers to build layouts for Android AppWidgets using a Jetpack Compose-style API.",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/glance#1.1.1",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.glance:glance-appwidget:1.1.1"
  },
  {
    "project": "Glance Material",
    "description": "Glance Material integration library. This library provides interop APIs with Material 3.",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/glance#1.1.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.glance:glance-material3:1.1.1"
  },
  {
    "project": "Glance Preview",
    "description": "Glance preview library. This library provides the API required for marking theglance @Composable components that should have preview in the Android Studio.",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/glance#1.1.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.glance:glance-preview:1.1.1"
  },
  {
    "project": "Glide",
    "description": "A fast and efficient image loading library for Android focused on smooth scrolling.",
    "version": "5.0.5",
    "developers": [
      "Sam Judd",
      "Sam Judd"
    ],
    "url": "https://github.com/bumptech/glide",
    "year": null,
    "licenses": [
      {
        "license": "Simplified BSD License",
        "license_url": "http://www.opensource.org/licenses/bsd-license"
      },
      {
        "license": "Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.github.bumptech.glide:glide:5.0.5"
  },
  {
    "project": "Glide Annotations",
    "description": "A set of annotations for configuring Glide.",
    "version": "5.0.5",
    "developers": [
      "Sam Judd",
      "Sam Judd"
    ],
    "url": "https://github.com/bumptech/glide",
    "year": null,
    "licenses": [
      {
        "license": "Simplified BSD License",
        "license_url": "http://www.opensource.org/licenses/bsd-license"
      },
      {
        "license": "Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.github.bumptech.glide:annotations:5.0.5"
  },
  {
    "project": "Glide Compose Integration",
    "description": "An integration library to integrate with Jetpack Compose",
    "version": "1.0.0-beta08",
    "developers": [
      "Sam Judd",
      "Sam Judd"
    ],
    "url": "https://github.com/bumptech/glide",
    "year": null,
    "licenses": [
      {
        "license": "Simplified BSD License",
        "license_url": "http://www.opensource.org/licenses/bsd-license"
      },
      {
        "license": "Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.github.bumptech.glide:compose:1.0.0-beta08"
  },
  {
    "project": "Glide Disk LRU Cache Library",
    "description": "A cache that uses a bounded amount of space on a filesystem. Based on Jake Wharton\u0027s tailored for Glide.",
    "version": "5.0.5",
    "developers": [
      "Sam Judd",
      "Sam Judd"
    ],
    "url": "https://github.com/bumptech/glide",
    "year": null,
    "licenses": [
      {
        "license": "Simplified BSD License",
        "license_url": "http://www.opensource.org/licenses/bsd-license"
      },
      {
        "license": "Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.github.bumptech.glide:disklrucache:5.0.5"
  },
  {
    "project": "Glide GIF Decoder Library",
    "description": "Implementation of GifDecoder that is more memory efficient to animate for Android devices.",
    "version": "5.0.5",
    "developers": [
      "Sam Judd",
      "Sam Judd"
    ],
    "url": "https://github.com/bumptech/glide",
    "year": null,
    "licenses": [
      {
        "license": "Simplified BSD License",
        "license_url": "http://www.opensource.org/licenses/bsd-license"
      },
      {
        "license": "Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.github.bumptech.glide:gifdecoder:5.0.5"
  },
  {
    "project": "Glide Kotlin Extensions",
    "description": "An integration library to improve Kotlin interop with Glide",
    "version": "1.0.0-beta08",
    "developers": [
      "Sam Judd",
      "Sam Judd"
    ],
    "url": "https://github.com/bumptech/glide",
    "year": null,
    "licenses": [
      {
        "license": "Simplified BSD License",
        "license_url": "http://www.opensource.org/licenses/bsd-license"
      },
      {
        "license": "Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.github.bumptech.glide:ktx:1.0.0-beta08"
  },
  {
    "project": "Glide RecyclerView Integration",
    "description": "An integration library to display images in RecyclerView.",
    "version": "5.0.5",
    "developers": [
      "Sam Judd",
      "Sam Judd"
    ],
    "url": "https://github.com/bumptech/glide",
    "year": null,
    "licenses": [
      {
        "license": "Simplified BSD License",
        "license_url": "http://www.opensource.org/licenses/bsd-license"
      },
      {
        "license": "Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.github.bumptech.glide:recyclerview-integration:5.0.5"
  },
  {
    "project": "Guava ListenableFuture only",
    "description": "Contains Guava\u0027s com.google.common.util.concurrent.ListenableFuture class,\n    without any of its other classes -- but is also available in a second\n    \"version\" that omits the class to avoid conflicts with the copy in Guava\n    itself. The idea is:\n\n    - If users want only ListenableFuture, they depend on listenablefuture-1.0.\n\n    - If users want all of Guava, they depend on guava, which, as of Guava\n    27.0, depends on\n    listenablefuture-9999.0-empty-to-avoid-conflict-with-guava. The 9999.0-...\n    version number is enough for some build systems (notably, Gradle) to select\n    that empty artifact over the \"real\" listenablefuture-1.0 -- avoiding a\n    conflict with the copy of ListenableFuture in guava itself. If users are\n    using an older version of Guava or a build system other than Gradle, they\n    may see class conflicts. If so, they can solve them by manually excluding\n    the listenablefuture artifact or manually forcing their build systems to\n    use 9999.0-....",
    "version": "1.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.guava:listenablefuture:1.0"
  },
  {
    "project": "Hilt Android",
    "description": "A fast dependency injector for Android and Java.",
    "version": "2.58",
    "developers": [
      ""
    ],
    "url": "https://github.com/google/dagger",
    "year": null,
    "licenses": [
      {
        "license": "Apache 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.dagger:hilt-android:2.58"
  },
  {
    "project": "Hilt Common",
    "description": "AndroidX Hilt Extension Annotations",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/hilt#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.hilt:hilt-common:1.2.0"
  },
  {
    "project": "Hilt Core",
    "description": "A fast dependency injector for Android and Java.",
    "version": "2.58",
    "developers": [
      ""
    ],
    "url": "https://github.com/google/dagger",
    "year": null,
    "licenses": [
      {
        "license": "Apache 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.dagger:hilt-core:2.58"
  },
  {
    "project": "human-verification-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:human-verification-data:36.6.1"
  },
  {
    "project": "human-verification-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:human-verification-domain:36.6.1"
  },
  {
    "project": "human-verification-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:human-verification-presentation:36.6.1"
  },
  {
    "project": "installreferrer",
    "description": null,
    "version": "2.2",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.android.installreferrer:installreferrer:2.2"
  },
  {
    "project": "IPAddress",
    "description": "Library for handling IP addresses, both IPv4 and IPv6",
    "version": "5.5.1",
    "developers": [
      "Sean C Foley"
    ],
    "url": "https://seancfoley.github.io/IPAddress/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.github.seancfoley:ipaddress:5.5.1"
  },
  {
    "project": "Jakarta Dependency Injection",
    "description": "Jakarta Dependency Injection",
    "version": "2.0.1",
    "developers": [
      "Antoine Sabot-Durand",
      "Martin Kouba",
      "Tomas Remes",
      "Matej Novotny"
    ],
    "url": "https://github.com/eclipse-ee4j/injection-api",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "jakarta.inject:jakarta.inject-api:2.0.1"
  },
  {
    "project": "Java Native Access",
    "description": "Java Native Access",
    "version": "5.18.1",
    "developers": [
      "Timothy Wall",
      "Matthias Bläsing"
    ],
    "url": "https://github.com/java-native-access/jna",
    "year": null,
    "licenses": [
      {
        "license": "LGPL-2.1-or-later",
        "license_url": "https://www.gnu.org/licenses/old-licenses/lgpl-2.1"
      },
      {
        "license": "Apache-2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "net.java.dev.jna:jna:5.18.1"
  },
  {
    "project": "javax.inject",
    "description": "The javax.inject API",
    "version": "1",
    "developers": [],
    "url": "http://code.google.com/p/atinject/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "javax.inject:javax.inject:1"
  },
  {
    "project": "JetBrains Java Annotations",
    "description": "A set of annotations used for code inspection support and code documentation.",
    "version": "23.0.0",
    "developers": [
      "JetBrains Team"
    ],
    "url": "https://github.com/JetBrains/java-annotations",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains:annotations:23.0.0"
  },
  {
    "project": "JSpecify annotations",
    "description": "An artifact of well-named and well-specified annotations to power static analysis checks",
    "version": "1.0.0",
    "developers": [
      "Kevin Bourrillion"
    ],
    "url": "http://jspecify.org/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jspecify:jspecify:1.0.0"
  },
  {
    "project": "Kermit",
    "description": "Kermit The Log",
    "version": "1.2.2",
    "developers": [
      "Kevin Galligan"
    ],
    "url": "https://github.com/touchlab/Kermit",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "co.touchlab:kermit-jvm:1.2.2"
  },
  {
    "project": "Kermit",
    "description": "Kermit The Log",
    "version": "1.2.2",
    "developers": [
      "Kevin Galligan"
    ],
    "url": "https://github.com/touchlab/Kermit",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "co.touchlab:kermit-android:1.2.2"
  },
  {
    "project": "key",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:key:36.6.1"
  },
  {
    "project": "key-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:key-dagger:36.6.1"
  },
  {
    "project": "key-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:key-data:36.6.1"
  },
  {
    "project": "key-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:key-domain:36.6.1"
  },
  {
    "project": "Kotlin Android Extensions Runtime",
    "description": "Kotlin Android Extensions Runtime",
    "version": "2.1.0",
    "developers": [
      "Kotlin Team"
    ],
    "url": "https://kotlinlang.org/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlin:kotlin-android-extensions-runtime:2.1.0"
  },
  {
    "project": "Kotlin Reflect",
    "description": "Kotlin Full Reflection Library",
    "version": "2.2.21",
    "developers": [
      "Kotlin Team"
    ],
    "url": "https://kotlinlang.org/",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlin:kotlin-reflect:2.2.21"
  },
  {
    "project": "Kotlin Stdlib",
    "description": "Kotlin Standard Library",
    "version": "2.3.20",
    "developers": [
      "Kotlin Team"
    ],
    "url": "https://kotlinlang.org/",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlin:kotlin-stdlib:2.3.20"
  },
  {
    "project": "Kotlin Stdlib Jdk7",
    "description": "Kotlin Standard Library JDK 7 extension",
    "version": "2.2.21",
    "developers": [
      "Kotlin Team"
    ],
    "url": "https://kotlinlang.org/",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlin:kotlin-stdlib-jdk7:2.2.21"
  },
  {
    "project": "Kotlin Stdlib Jdk8",
    "description": "Kotlin Standard Library JDK 8 extension",
    "version": "2.2.21",
    "developers": [
      "Kotlin Team"
    ],
    "url": "https://kotlinlang.org/",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlin:kotlin-stdlib-jdk8:2.2.21"
  },
  {
    "project": "kotlinx-coroutines-android",
    "description": "Coroutines support libraries for Kotlin",
    "version": "1.10.2",
    "developers": [
      "JetBrains Team"
    ],
    "url": "https://github.com/Kotlin/kotlinx.coroutines",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2"
  },
  {
    "project": "kotlinx-coroutines-core",
    "description": "Coroutines support libraries for Kotlin",
    "version": "1.10.2",
    "developers": [
      "JetBrains Team"
    ],
    "url": "https://github.com/Kotlin/kotlinx.coroutines",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlinx:kotlinx-coroutines-core-jvm:1.10.2"
  },
  {
    "project": "kotlinx-datetime",
    "description": "Kotlin Datetime Library",
    "version": "0.4.0",
    "developers": [
      "JetBrains Team"
    ],
    "url": "https://github.com/Kotlin/kotlinx-datetime",
    "year": null,
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlinx:kotlinx-datetime-jvm:0.4.0"
  },
  {
    "project": "kotlinx-serialization-cbor",
    "description": "Kotlin multiplatform serialization runtime library",
    "version": "1.11.0",
    "developers": [
      "JetBrains Team"
    ],
    "url": "https://github.com/Kotlin/kotlinx.serialization",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlinx:kotlinx-serialization-cbor-jvm:1.11.0"
  },
  {
    "project": "kotlinx-serialization-core",
    "description": "Kotlin multiplatform serialization runtime library",
    "version": "1.11.0",
    "developers": [
      "JetBrains Team"
    ],
    "url": "https://github.com/Kotlin/kotlinx.serialization",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlinx:kotlinx-serialization-core-jvm:1.11.0"
  },
  {
    "project": "kotlinx-serialization-json",
    "description": "Kotlin multiplatform serialization runtime library",
    "version": "1.11.0",
    "developers": [
      "JetBrains Team"
    ],
    "url": "https://github.com/Kotlin/kotlinx.serialization",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlinx:kotlinx-serialization-json-jvm:1.11.0"
  },
  {
    "project": "Leanback",
    "description": "Android Support Leanback v17",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/leanback#1.2.0",
    "year": "2014",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.leanback:leanback:1.2.0"
  },
  {
    "project": "Leanback Grid",
    "description": "This library adds grid view components to be used in TV",
    "version": "1.0.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/leanback#1.0.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.leanback:leanback-grid:1.0.0"
  },
  {
    "project": "Leanback Preference",
    "description": "AndroidX Leanback Preference",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/leanback#1.2.0",
    "year": "2015",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.leanback:leanback-preference:1.2.0"
  },
  {
    "project": "Lifecycle Kotlin Extensions",
    "description": "Kotlin extensions for \u0027lifecycle\u0027 artifact",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-runtime-ktx-android:2.10.0"
  },
  {
    "project": "Lifecycle LiveData",
    "description": "Android Lifecycle LiveData",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-livedata:2.10.0"
  },
  {
    "project": "Lifecycle LiveData Core",
    "description": "Android Lifecycle LiveData Core",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-livedata-core:2.10.0"
  },
  {
    "project": "Lifecycle Process",
    "description": "Android Lifecycle Process",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-process:2.10.0"
  },
  {
    "project": "Lifecycle Runtime",
    "description": "Android Lifecycle Runtime",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-runtime-desktop:2.10.0"
  },
  {
    "project": "Lifecycle Runtime",
    "description": "Android Lifecycle Runtime",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-runtime-android:2.10.0"
  },
  {
    "project": "Lifecycle Runtime Compose",
    "description": "Compose integration with Lifecycle",
    "version": "2.9.5",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.androidx.lifecycle:lifecycle-runtime-compose-desktop:2.9.5"
  },
  {
    "project": "Lifecycle Runtime Compose",
    "description": "Compose integration with Lifecycle",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-runtime-compose-desktop:2.10.0"
  },
  {
    "project": "Lifecycle Runtime Compose",
    "description": "Compose integration with Lifecycle",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-runtime-compose-android:2.10.0"
  },
  {
    "project": "Lifecycle Service",
    "description": "Android Lifecycle Service",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-service:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel",
    "description": "Android Lifecycle ViewModel",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel-desktop:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel",
    "description": "Android Lifecycle ViewModel",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel",
    "description": "Android Lifecycle ViewModel",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel-android:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel Compose",
    "description": "Compose integration with Lifecycle ViewModel",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel-compose-jvmstubs:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel Compose",
    "description": "Compose integration with Lifecycle ViewModel",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel-compose-android:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel Kotlin Extensions",
    "description": "Kotlin extensions for \u0027viewmodel\u0027 artifact",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel-ktx:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel with SavedState",
    "description": "Android Lifecycle ViewModel",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel-savedstate-desktop:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel with SavedState",
    "description": "Android Lifecycle ViewModel",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel-savedstate:2.10.0"
  },
  {
    "project": "Lifecycle ViewModel with SavedState",
    "description": "Android Lifecycle ViewModel",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-viewmodel-savedstate-android:2.10.0"
  },
  {
    "project": "Lifecycle-Common",
    "description": "Android Lifecycle-Common",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-common-jvm:2.10.0"
  },
  {
    "project": "Lifecycle-Common for Java 8",
    "description": "Android Lifecycle-Common for Java 8 Language",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-common-java8:2.10.0"
  },
  {
    "project": "LiveData Core Kotlin Extensions",
    "description": "Kotlin extensions for \u0027livedata-core\u0027 artifact",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-livedata-core-ktx:2.10.0"
  },
  {
    "project": "LiveData Kotlin Extensions",
    "description": "Kotlin extensions for \u0027livedata\u0027 artifact",
    "version": "2.10.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/lifecycle#2.10.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.lifecycle:lifecycle-livedata-ktx:2.10.0"
  },
  {
    "project": "logback-android",
    "description": "\"Logging library for Android apps\"",
    "version": "2.0.0",
    "developers": [
      "tony19"
    ],
    "url": "https://github.com/tony19/logback-android",
    "year": null,
    "licenses": [
      {
        "license": "\"The Apache Software License, Version 2.0\"",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0"
      }
    ],
    "dependency": "com.github.tony19:logback-android:2.0.0"
  },
  {
    "project": "Lottie",
    "description": "Lottie is an animation library that renders Adobe After Effects animations natively in realtime.",
    "version": "6.6.7",
    "developers": [
      "Airbnb"
    ],
    "url": "https://github.com/airbnb/lottie-android",
    "year": "2017",
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0"
      }
    ],
    "dependency": "com.airbnb.android:lottie:6.6.7"
  },
  {
    "project": "Lottie Compose",
    "description": "Lottie for Jetpack Compose.",
    "version": "6.6.7",
    "developers": [
      "Airbnb"
    ],
    "url": "https://github.com/airbnb/lottie-android",
    "year": "2020",
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0"
      }
    ],
    "dependency": "com.airbnb.android:lottie-compose:6.6.7"
  },
  {
    "project": "Material Components for Android",
    "description": "Material Components for Android is a static library that you can add to your Android application in order to use APIs that provide implementations of the Material Design specification. Compatible on devices running API 14 or later.",
    "version": "1.12.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://github.com/material-components/material-components-android",
    "year": "2015",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.android.material:material:1.12.0"
  },
  {
    "project": "me.proton.vpn:android-vpn-rust",
    "description": "Rust library with code for Android Proton VPN client",
    "version": "1.0.37",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://protonvpn.com",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.vpn:android-vpn-rust:1.0.37"
  },
  {
    "project": "me.proton.vpn:go-vpn-lib",
    "description": "Go library with shared code for Proton VPN clients",
    "version": "0.1.87",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonVPN/go-vpn-lib",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.vpn:go-vpn-lib:0.1.87"
  },
  {
    "project": "me.proton.vpn:vpn-core-internal",
    "description": "Proton VPN core libraries for Android",
    "version": "0.1.55-1.0.37",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://protonvpn.com",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.vpn:vpn-core-internal:0.1.55-1.0.37"
  },
  {
    "project": "minidns",
    "description": "A DNS library for Java and Android systems",
    "version": "1.0.4",
    "developers": [
      "Rene Treffer",
      "Florian Schmaus"
    ],
    "url": "https://github.com/minidns/minidns",
    "year": "2014",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.minidns:minidns-core:1.0.4"
  },
  {
    "project": "Navigation Common",
    "description": "Android Navigation-Common",
    "version": "2.9.7",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigation#2.9.7",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigation:navigation-common-jvmstubs:2.9.7"
  },
  {
    "project": "Navigation Common",
    "description": "Android Navigation-Common",
    "version": "2.9.7",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigation#2.9.7",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigation:navigation-common-android:2.9.7"
  },
  {
    "project": "Navigation Compose Hilt Integration",
    "description": "Navigation Compose Hilt Integration",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/hilt#1.2.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.hilt:hilt-navigation-compose:1.2.0"
  },
  {
    "project": "Navigation Event",
    "description": "Provides APIs to easily intercept platform navigation events, including swipes and clicks, to provide a consistent API surface for handling these events.",
    "version": "1.0.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigationevent#1.0.2",
    "year": "2025",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigationevent:navigationevent-desktop:1.0.2"
  },
  {
    "project": "Navigation Event",
    "description": "Provides APIs to easily intercept platform navigation events, including swipes and clicks, to provide a consistent API surface for handling these events.",
    "version": "1.0.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigationevent#1.0.2",
    "year": "2025",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigationevent:navigationevent-android:1.0.2"
  },
  {
    "project": "Navigation Hilt Extension",
    "description": "Android Navigation Hilt Extension",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/hilt#1.2.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.hilt:hilt-navigation:1.2.0"
  },
  {
    "project": "Navigation Runtime",
    "description": "Android Navigation-Runtime",
    "version": "2.9.7",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigation#2.9.7",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigation:navigation-runtime-jvmstubs:2.9.7"
  },
  {
    "project": "Navigation Runtime",
    "description": "Android Navigation-Runtime",
    "version": "2.9.7",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigation#2.9.7",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigation:navigation-runtime-android:2.9.7"
  },
  {
    "project": "NavigationEvent Compose",
    "description": "Compose integration with NavigationEvent",
    "version": "1.0.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigationevent#1.0.2",
    "year": "2025",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigationevent:navigationevent-compose-jvmstubs:1.0.2"
  },
  {
    "project": "NavigationEvent Compose",
    "description": "Compose integration with NavigationEvent",
    "version": "1.0.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/navigationevent#1.0.2",
    "year": "2025",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.navigationevent:navigationevent-compose-android:1.0.2"
  },
  {
    "project": "network-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:network-data:36.6.1"
  },
  {
    "project": "network-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:network-domain:36.6.1"
  },
  {
    "project": "network-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:network-presentation:36.6.1"
  },
  {
    "project": "notification-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:notification-data:36.6.1"
  },
  {
    "project": "notification-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:notification-domain:36.6.1"
  },
  {
    "project": "notification-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:notification-presentation:36.6.1"
  },
  {
    "project": "observability",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:observability:36.6.1"
  },
  {
    "project": "observability-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:observability-dagger:36.6.1"
  },
  {
    "project": "observability-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:observability-data:36.6.1"
  },
  {
    "project": "observability-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:observability-domain:36.6.1"
  },
  {
    "project": "okhttp",
    "description": "Square’s meticulous HTTP client for Java and Kotlin.",
    "version": "4.12.0",
    "developers": [
      "Square, Inc."
    ],
    "url": "https://square.github.io/okhttp/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.squareup.okhttp3:okhttp:4.12.0"
  },
  {
    "project": "okhttp-logging-interceptor",
    "description": "Square’s meticulous HTTP client for Java and Kotlin.",
    "version": "4.12.0",
    "developers": [
      "Square, Inc."
    ],
    "url": "https://square.github.io/okhttp/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.squareup.okhttp3:logging-interceptor:4.12.0"
  },
  {
    "project": "okio",
    "description": "A modern I/O library for Android, Java, and Kotlin Multiplatform.",
    "version": "3.9.1",
    "developers": [
      "Square, Inc."
    ],
    "url": "https://github.com/square/okio/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.squareup.okio:okio-jvm:3.9.1"
  },
  {
    "project": "org.mobilenativefoundation.store",
    "description": "Store5 is a Kotlin Multiplatform network-resilient repository layer",
    "version": "5.0.0",
    "developers": [
      "Dropbox"
    ],
    "url": "https://github.com/MobileNativeFoundation/Store",
    "year": null,
    "licenses": [
      {
        "license": "Apache License",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0"
      }
    ],
    "dependency": "org.mobilenativefoundation.store:store5-jvm:5.0.0"
  },
  {
    "project": "org.mobilenativefoundation.store",
    "description": "Store5 is a Kotlin Multiplatform network-resilient repository layer",
    "version": "5.0.0",
    "developers": [
      "Dropbox"
    ],
    "url": "https://github.com/MobileNativeFoundation/Store",
    "year": null,
    "licenses": [
      {
        "license": "Apache License",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0"
      }
    ],
    "dependency": "org.mobilenativefoundation.store:cache5-jvm:5.0.0"
  },
  {
    "project": "org.mobilenativefoundation.store",
    "description": "Store5 is a Kotlin Multiplatform network-resilient repository layer",
    "version": "5.0.0",
    "developers": [
      "Dropbox"
    ],
    "url": "https://github.com/MobileNativeFoundation/Store",
    "year": null,
    "licenses": [
      {
        "license": "Apache License",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0"
      }
    ],
    "dependency": "org.mobilenativefoundation.store:multicast5-jvm:5.0.0"
  },
  {
    "project": "Parcelize Runtime",
    "description": "Runtime library for the Parcelize compiler plugin",
    "version": "2.2.21",
    "developers": [
      "Kotlin Team"
    ],
    "url": "https://kotlinlang.org/",
    "year": null,
    "licenses": [
      {
        "license": "Apache-2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.kotlin:kotlin-parcelize-runtime:2.2.21"
  },
  {
    "project": "pass-validator",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:pass-validator:36.6.1"
  },
  {
    "project": "pass-validator-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:pass-validator-dagger:36.6.1"
  },
  {
    "project": "pass-validator-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:pass-validator-data:36.6.1"
  },
  {
    "project": "pass-validator-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:pass-validator-domain:36.6.1"
  },
  {
    "project": "pass-validator-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:pass-validator-presentation:36.6.1"
  },
  {
    "project": "payment",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment:36.6.1"
  },
  {
    "project": "payment-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-dagger:36.6.1"
  },
  {
    "project": "payment-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-data:36.6.1"
  },
  {
    "project": "payment-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-domain:36.6.1"
  },
  {
    "project": "payment-iap",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-iap:36.6.1"
  },
  {
    "project": "payment-iap-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-iap-dagger:36.6.1"
  },
  {
    "project": "payment-iap-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-iap-data:36.6.1"
  },
  {
    "project": "payment-iap-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-iap-domain:36.6.1"
  },
  {
    "project": "payment-iap-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-iap-presentation:36.6.1"
  },
  {
    "project": "payment-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:payment-presentation:36.6.1"
  },
  {
    "project": "plan",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:plan:36.6.1"
  },
  {
    "project": "plan-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:plan-dagger:36.6.1"
  },
  {
    "project": "plan-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:plan-data:36.6.1"
  },
  {
    "project": "plan-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:plan-domain:36.6.1"
  },
  {
    "project": "plan-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:plan-presentation:36.6.1"
  },
  {
    "project": "play-services-base",
    "description": null,
    "version": "18.5.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.google.android.gms:play-services-base:18.5.0"
  },
  {
    "project": "play-services-basement",
    "description": null,
    "version": "18.5.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.google.android.gms:play-services-basement:18.5.0"
  },
  {
    "project": "play-services-fido",
    "description": null,
    "version": "21.2.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.google.android.gms:play-services-fido:21.2.0"
  },
  {
    "project": "play-services-location",
    "description": null,
    "version": "19.0.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.google.android.gms:play-services-location:19.0.0"
  },
  {
    "project": "play-services-places-placereport",
    "description": null,
    "version": "17.0.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.google.android.gms:play-services-places-placereport:17.0.0"
  },
  {
    "project": "play-services-tasks",
    "description": null,
    "version": "18.2.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Android Software Development Kit License",
        "license_url": "https://developer.android.com/studio/terms.html"
      }
    ],
    "dependency": "com.google.android.gms:play-services-tasks:18.2.0"
  },
  {
    "project": "Preferences DataStore",
    "description": "Android Preferences DataStore",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-preferences-jvm:1.2.0"
  },
  {
    "project": "Preferences DataStore",
    "description": "Android Preferences DataStore",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-preferences-android:1.2.0"
  },
  {
    "project": "Preferences DataStore Core",
    "description": "Android Preferences DataStore without the Android Dependencies",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-preferences-core-jvm:1.2.0"
  },
  {
    "project": "Preferences DataStore Core",
    "description": "Android Preferences DataStore without the Android Dependencies",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-preferences-core-android:1.2.0"
  },
  {
    "project": "Preferences DataStore Proto",
    "description": "Jarjar the generated proto for use by datastore-preferences.",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.datastore:datastore-preferences-proto:1.2.0"
  },
  {
    "project": "Preferences External Protobuf",
    "description": "Repackaged proto-lite dependency for use by datastore preferences",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/datastore#1.2.0",
    "year": "2024",
    "licenses": [
      {
        "license": "BSD-3-Clause",
        "license_url": "https://opensource.org/licenses/BSD-3-Clause"
      }
    ],
    "dependency": "androidx.datastore:datastore-preferences-external-protobuf:1.2.0"
  },
  {
    "project": "presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:presentation:36.6.1"
  },
  {
    "project": "presentation-compose",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:presentation-compose:36.6.1"
  },
  {
    "project": "presentation-compose-tv",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:presentation-compose-tv:36.6.1"
  },
  {
    "project": "Profile Installer",
    "description": "Allows libraries to prepopulate ahead of time compilation traces to be read by ART",
    "version": "1.4.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/profileinstaller#1.4.1",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.profileinstaller:profileinstaller:1.4.1"
  },
  {
    "project": "push",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:push:36.6.1"
  },
  {
    "project": "push-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:push-dagger:36.6.1"
  },
  {
    "project": "push-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:push-data:36.6.1"
  },
  {
    "project": "push-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:push-domain:36.6.1"
  },
  {
    "project": "RemoteViews",
    "description": "AndroidX RemoteViews Support",
    "version": "1.1.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/core#1.1.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.core:core-remoteviews:1.1.0"
  },
  {
    "project": "Reorderable",
    "description": "A library for reordering items in a LazyColumn",
    "version": "2.4.3",
    "developers": [
      "Calvin Liang"
    ],
    "url": "https://github.com/Calvin-LL/Reorderable",
    "year": "2023",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "sh.calvin.reorderable:reorderable-jvm:2.4.3"
  },
  {
    "project": "Reorderable",
    "description": "A library for reordering items in a LazyColumn",
    "version": "2.4.3",
    "developers": [
      "Calvin Liang"
    ],
    "url": "https://github.com/Calvin-LL/Reorderable",
    "year": "2023",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "sh.calvin.reorderable:reorderable-android:2.4.3"
  },
  {
    "project": "Retrofit",
    "description": "A type-safe HTTP client for Android and Java.",
    "version": "2.12.0",
    "developers": [
      "Square, Inc."
    ],
    "url": "https://github.com/square/retrofit",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.squareup.retrofit2:retrofit:2.12.0"
  },
  {
    "project": "Retrofit 2 Kotlin Serialization Converter",
    "description": "A Converter.Factory for Kotlin\u0027s serialization support.",
    "version": "1.0.0",
    "developers": [
      "Jake Wharton"
    ],
    "url": "https://github.com/JakeWharton/retrofit2-kotlinx-serialization-converter/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.jakewharton.retrofit:retrofit2-kotlinx-serialization-converter:1.0.0"
  },
  {
    "project": "review",
    "description": null,
    "version": "2.0.2",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Play Core Software Development Kit Terms of Service",
        "license_url": "https://developer.android.com/guide/playcore/license"
      }
    ],
    "dependency": "com.google.android.play:review:2.0.2"
  },
  {
    "project": "review-ktx",
    "description": null,
    "version": "2.0.2",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Play Core Software Development Kit Terms of Service",
        "license_url": "https://developer.android.com/guide/playcore/license"
      }
    ],
    "dependency": "com.google.android.play:review-ktx:2.0.2"
  },
  {
    "project": "Room Kotlin Extensions",
    "description": "Android Room Kotlin Extensions",
    "version": "2.7.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/room#2.7.2",
    "year": "2019",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.room:room-ktx:2.7.2"
  },
  {
    "project": "Room-Common",
    "description": "Android Room-Common",
    "version": "2.7.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/room#2.7.2",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.room:room-common-jvm:2.7.2"
  },
  {
    "project": "Room-Runtime",
    "description": "Android Room-Runtime",
    "version": "2.7.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/room#2.7.2",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.room:room-runtime-jvm:2.7.2"
  },
  {
    "project": "Room-Runtime",
    "description": "Android Room-Runtime",
    "version": "2.7.2",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/room#2.7.2",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.room:room-runtime-android:2.7.2"
  },
  {
    "project": "Saved State",
    "description": "Android Lifecycle Saved State",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/savedstate#1.4.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.savedstate:savedstate:1.4.0"
  },
  {
    "project": "Saved State",
    "description": "Android Lifecycle Saved State",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/savedstate#1.4.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.savedstate:savedstate-desktop:1.4.0"
  },
  {
    "project": "Saved State",
    "description": "Android Lifecycle Saved State",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/savedstate#1.4.0",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.savedstate:savedstate-android:1.4.0"
  },
  {
    "project": "Saved State Compose",
    "description": "Compose integration with Saved State",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/savedstate#1.4.0",
    "year": "2024",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.savedstate:savedstate-compose-desktop:1.4.0"
  },
  {
    "project": "Saved State Compose",
    "description": "Compose integration with Saved State",
    "version": "1.3.5",
    "developers": [
      "Compose Multiplatform Team"
    ],
    "url": "https://github.com/JetBrains/compose-jb",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "org.jetbrains.androidx.savedstate:savedstate-compose-desktop:1.3.5"
  },
  {
    "project": "Saved State Compose",
    "description": "Compose integration with Saved State",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/savedstate#1.4.0",
    "year": "2024",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.savedstate:savedstate-compose-android:1.4.0"
  },
  {
    "project": "SavedState Kotlin Extensions",
    "description": "Kotlin extensions for \u0027savedstate\u0027 artifact",
    "version": "1.4.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/savedstate#1.4.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.savedstate:savedstate-ktx:1.4.0"
  },
  {
    "project": "Sentry SDK",
    "description": "SDK for sentry.io",
    "version": "7.22.5",
    "developers": [
      "Sentry Team and Contributors"
    ],
    "url": "https://github.com/getsentry/sentry-java",
    "year": null,
    "licenses": [
      {
        "license": "MIT",
        "license_url": "http://www.opensource.org/licenses/mit-license.php"
      }
    ],
    "dependency": "io.sentry:sentry-android-ndk:7.22.5"
  },
  {
    "project": "Sentry SDK",
    "description": "SDK for sentry.io",
    "version": "7.22.5",
    "developers": [
      "Sentry Team and Contributors"
    ],
    "url": "https://github.com/getsentry/sentry-java",
    "year": null,
    "licenses": [
      {
        "license": "MIT",
        "license_url": "http://www.opensource.org/licenses/mit-license.php"
      }
    ],
    "dependency": "io.sentry:sentry:7.22.5"
  },
  {
    "project": "Sentry SDK",
    "description": "SDK for sentry.io",
    "version": "7.22.5",
    "developers": [
      "Sentry Team and Contributors"
    ],
    "url": "https://github.com/getsentry/sentry-java",
    "year": null,
    "licenses": [
      {
        "license": "MIT",
        "license_url": "http://www.opensource.org/licenses/mit-license.php"
      }
    ],
    "dependency": "io.sentry:sentry-android-core:7.22.5"
  },
  {
    "project": "Sentry SDK",
    "description": "SDK for sentry.io",
    "version": "7.22.5",
    "developers": [
      "Sentry Team and Contributors"
    ],
    "url": "https://github.com/getsentry/sentry-java",
    "year": null,
    "licenses": [
      {
        "license": "MIT",
        "license_url": "http://www.opensource.org/licenses/mit-license.php"
      }
    ],
    "dependency": "io.sentry:sentry-android-replay:7.22.5"
  },
  {
    "project": "Sentry SDK",
    "description": "SDK for sentry.io",
    "version": "7.22.5",
    "developers": [
      "Sentry Team and Contributors"
    ],
    "url": "https://github.com/getsentry/sentry-java",
    "year": null,
    "licenses": [
      {
        "license": "MIT",
        "license_url": "http://www.opensource.org/licenses/mit-license.php"
      }
    ],
    "dependency": "io.sentry:sentry-android:7.22.5"
  },
  {
    "project": "SLF4J API Module",
    "description": "The slf4j API",
    "version": "1.7.36",
    "developers": [],
    "url": "http://www.slf4j.org",
    "year": null,
    "licenses": [
      {
        "license": "MIT License",
        "license_url": "http://www.opensource.org/licenses/mit-license.php"
      }
    ],
    "dependency": "org.slf4j:slf4j-api:1.7.36"
  },
  {
    "project": "SplashScreen",
    "description": "This library provides the compatibility APIs for SplashScreen and helper method to enable a splashscreen on devices prior Android 12",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/core#1.2.0",
    "year": "2021",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.core:core-splashscreen:1.2.0"
  },
  {
    "project": "SQLite",
    "description": "SQLite API",
    "version": "2.5.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/sqlite#2.5.1",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.sqlite:sqlite-jvm:2.5.1"
  },
  {
    "project": "SQLite",
    "description": "SQLite API",
    "version": "2.5.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/sqlite#2.5.1",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.sqlite:sqlite-android:2.5.1"
  },
  {
    "project": "SQLite Framework Integration",
    "description": "The implementation of SQLite library using the framework code.",
    "version": "2.5.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/sqlite#2.5.1",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.sqlite:sqlite-framework-android:2.5.1"
  },
  {
    "project": "Stately",
    "description": "Multithreaded Kotlin Multiplatform Utilities",
    "version": "2.0.6",
    "developers": [
      "Kevin Galligan"
    ],
    "url": "https://github.com/touchlab/Stately",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "co.touchlab:stately-isolate-jvm:2.0.6"
  },
  {
    "project": "Stately",
    "description": "Multithreaded Kotlin Multiplatform Utilities",
    "version": "2.0.6",
    "developers": [
      "Kevin Galligan"
    ],
    "url": "https://github.com/touchlab/Stately",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "co.touchlab:stately-common-jvm:2.0.6"
  },
  {
    "project": "Stately",
    "description": "Multithreaded Kotlin Multiplatform Utilities",
    "version": "2.0.6",
    "developers": [
      "Kevin Galligan"
    ],
    "url": "https://github.com/touchlab/Stately",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "co.touchlab:stately-strict-jvm:2.0.6"
  },
  {
    "project": "Stately",
    "description": "Multithreaded Kotlin Multiplatform Utilities",
    "version": "2.0.6",
    "developers": [
      "Kevin Galligan"
    ],
    "url": "https://github.com/touchlab/Stately",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "co.touchlab:stately-concurrency-jvm:2.0.6"
  },
  {
    "project": "Stately",
    "description": "Multithreaded Kotlin Multiplatform Utilities",
    "version": "2.0.6",
    "developers": [
      "Kevin Galligan"
    ],
    "url": "https://github.com/touchlab/Stately",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "co.touchlab:stately-iso-collections-jvm:2.0.6"
  },
  {
    "project": "swagger-annotations",
    "description": "swagger-annotations",
    "version": "2.2.7",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "Apache License 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.html"
      }
    ],
    "dependency": "io.swagger.core.v3:swagger-annotations:2.2.7"
  },
  {
    "project": "telemetry-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:telemetry-data:36.6.1"
  },
  {
    "project": "telemetry-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:telemetry-domain:36.6.1"
  },
  {
    "project": "telemetry-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:telemetry-presentation:36.6.1"
  },
  {
    "project": "Timber",
    "description": "No-nonsense injectable logging.",
    "version": "5.0.1",
    "developers": [
      "Jake Wharton"
    ],
    "url": "https://github.com/JakeWharton/timber",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.jakewharton.timber:timber:5.0.1"
  },
  {
    "project": "Transition",
    "description": "Android Transition Support Library",
    "version": "1.6.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/transition#1.6.0",
    "year": "2016",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.transition:transition:1.6.0"
  },
  {
    "project": "transport-api",
    "description": null,
    "version": "3.0.0",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.android.datatransport:transport-api:3.0.0"
  },
  {
    "project": "transport-backend-cct",
    "description": null,
    "version": "3.1.8",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.android.datatransport:transport-backend-cct:3.1.8"
  },
  {
    "project": "transport-runtime",
    "description": null,
    "version": "3.1.8",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.android.datatransport:transport-runtime:3.1.8"
  },
  {
    "project": "TV Foundation",
    "description": "This library makes it easier for developersto write Jetpack Compose applications for TV devices by providing functionality to support TV specific devices sizes, shapes and d-pad navigation supported components. It builds upon the Jetpack Compose libraries.",
    "version": "1.0.0-beta01",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/tv#1.0.0-beta01",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.tv:tv-foundation:1.0.0-beta01"
  },
  {
    "project": "TV Material",
    "description": "build TV applications using controls that adhere to Material Design Language.",
    "version": "1.1.0-beta01",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/tv#1.1.0-beta01",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.tv:tv-material:1.1.0-beta01"
  },
  {
    "project": "user",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user:36.6.1"
  },
  {
    "project": "user-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-dagger:36.6.1"
  },
  {
    "project": "user-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-data:36.6.1"
  },
  {
    "project": "user-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-domain:36.6.1"
  },
  {
    "project": "user-recovery",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-recovery:36.6.1"
  },
  {
    "project": "user-recovery-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-recovery-dagger:36.6.1"
  },
  {
    "project": "user-recovery-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-recovery-data:36.6.1"
  },
  {
    "project": "user-recovery-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-recovery-domain:36.6.1"
  },
  {
    "project": "user-recovery-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-recovery-presentation:36.6.1"
  },
  {
    "project": "user-recovery-presentation-compose",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-recovery-presentation-compose:36.6.1"
  },
  {
    "project": "user-settings",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-settings:36.6.1"
  },
  {
    "project": "user-settings-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-settings-dagger:36.6.1"
  },
  {
    "project": "user-settings-data",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-settings-data:36.6.1"
  },
  {
    "project": "user-settings-domain",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-settings-domain:36.6.1"
  },
  {
    "project": "user-settings-presentation",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-settings-presentation:36.6.1"
  },
  {
    "project": "user-settings-presentation-compose",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:user-settings-presentation-compose:36.6.1"
  },
  {
    "project": "util-android-dagger",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:util-android-dagger:36.6.1"
  },
  {
    "project": "util-android-datetime",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:util-android-datetime:36.6.1"
  },
  {
    "project": "util-android-device",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:util-android-device:36.6.1"
  },
  {
    "project": "util-android-sentry",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:util-android-sentry:36.6.1"
  },
  {
    "project": "util-android-shared-preferences",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:util-android-shared-preferences:36.6.1"
  },
  {
    "project": "util-android-work-manager",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:util-android-work-manager:36.6.1"
  },
  {
    "project": "util-kotlin",
    "description": "Proton Core libraries for Android",
    "version": "36.6.1",
    "developers": [
      "Open Source Proton"
    ],
    "url": "https://github.com/ProtonMail/protoncore_android",
    "year": null,
    "licenses": [
      {
        "license": "GNU GENERAL PUBLIC LICENSE, Version 3.0",
        "license_url": "https://www.gnu.org/licenses/gpl-3.0.en.html"
      }
    ],
    "dependency": "me.proton.core:util-kotlin:36.6.1"
  },
  {
    "project": "VectorDrawable",
    "description": "Android Support VectorDrawable",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/vectordrawable#1.2.0",
    "year": "2015",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.vectordrawable:vectordrawable:1.2.0"
  },
  {
    "project": "VersionedParcelable",
    "description": "Provides a stable but relatively compact binary serialization format that can be passed across processes or persisted safely.",
    "version": "1.1.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "http://developer.android.com/tools/extras/support-library.html",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.versionedparcelable:versionedparcelable:1.1.1"
  },
  {
    "project": "Vico",
    "description": "A light and extensible chart library for Android.",
    "version": "2.0.0-alpha.14",
    "developers": [
      "Patryk Goworowski",
      "Patrick Michalik"
    ],
    "url": "https://github.com/patrykandpatrick/vico",
    "year": null,
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.patrykandpatrick.vico:core:2.0.0-alpha.14"
  },
  {
    "project": "Vico",
    "description": "A light and extensible chart library for Android.",
    "version": "2.0.0-alpha.14",
    "developers": [
      "Patryk Goworowski",
      "Patrick Michalik"
    ],
    "url": "https://github.com/patrykandpatrick/vico",
    "year": null,
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.patrykandpatrick.vico:compose:2.0.0-alpha.14"
  },
  {
    "project": "viewbinding",
    "description": null,
    "version": "8.9.1",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.databinding:viewbinding:8.9.1"
  },
  {
    "project": "ViewPager2",
    "description": "AndroidX Widget ViewPager2",
    "version": "1.1.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/viewpager2#1.1.0",
    "year": "2017",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.viewpager2:viewpager2:1.1.0"
  },
  {
    "project": "WindowManager",
    "description": "WindowManager Jetpack library. Currently only provides additional functionality on foldable devices.",
    "version": "1.5.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/window#1.5.1",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.window:window:1.5.1"
  },
  {
    "project": "WindowManager Core",
    "description": "WindowManager Core Library.",
    "version": "1.5.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/window#1.5.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.window:window-core-jvm:1.5.1"
  },
  {
    "project": "WindowManager Core",
    "description": "WindowManager Core Library.",
    "version": "1.5.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/window#1.5.1",
    "year": "2022",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.window:window-core-android:1.5.1"
  },
  {
    "project": "WireGuard Tunnel Library",
    "description": "Embeddable tunnel library for WireGuard for Android",
    "version": "1.0.20230512.29",
    "developers": [
      "WireGuard",
      "Open Source Proton"
    ],
    "url": "https://www.wireguard.com/",
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "me.proton.vpn:wireguard-android:1.0.20230512.29"
  },
  {
    "project": "WorkManager Hilt Extension",
    "description": "Android Lifecycle WorkManager Hilt Extension",
    "version": "1.2.0",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/hilt#1.2.0",
    "year": "2020",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.hilt:hilt-work:1.2.0"
  },
  {
    "project": "WorkManager Kotlin Extensions",
    "description": "Android WorkManager Kotlin Extensions",
    "version": "2.9.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/work#2.9.1",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.work:work-runtime-ktx:2.9.1"
  },
  {
    "project": "WorkManager Runtime",
    "description": "Android WorkManager runtime library",
    "version": "2.9.1",
    "developers": [
      "The Android Open Source Project"
    ],
    "url": "https://developer.android.com/jetpack/androidx/releases/work#2.9.1",
    "year": "2018",
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "http://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "androidx.work:work-runtime:2.9.1"
  },
  {
    "project": "ZXing Core",
    "description": "Core barcode encoding/decoding library",
    "version": "3.5.3",
    "developers": [],
    "url": null,
    "year": null,
    "licenses": [
      {
        "license": "The Apache Software License, Version 2.0",
        "license_url": "https://www.apache.org/licenses/LICENSE-2.0.txt"
      }
    ],
    "dependency": "com.google.zxing:core:3.5.3"
  },
  {
    "project": "zxing-android-embedded",
    "description": "Barcode scanner library for Android, based on the ZXing decoder",
    "version": "4.3.0",
    "developers": [
      "Ralf Kistner"
    ],
    "url": "https://github.com/journeyapps/zxing-android-embedded",
    "year": null,
    "licenses": [
      {
        "license": "The Apache License, Version 2.0",
        "license_url": "https://github.com/journeyapps/zxing-android-embedded/blob/master/COPYING"
      }
    ],
    "dependency": "com.journeyapps:zxing-android-embedded:4.3.0"
  }
]