/*
 * Copyright (c) 2025. Proton AG
 *
 * This file is part of ProtonVPN.
 *
 * ProtonVPN is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ProtonVPN is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ProtonVPN.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.protonvpn.android.promooffers.ui

import androidx.lifecycle.ViewModel
import com.protonvpn.android.promooffers.data.ApiNotificationActions
import com.protonvpn.android.promooffers.data.ApiNotificationManager
import com.protonvpn.android.promooffers.data.ApiNotificationOfferButton
import com.protonvpn.android.promooffers.data.ApiNotificationOfferFullScreenImage
import com.protonvpn.android.promooffers.data.ApiNotificationTypes
import com.protonvpn.android.promooffers.usecase.EnsureIapOfferStillValid
import com.protonvpn.android.telemetry.UpgradeTrigger
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.first
import me.proton.core.util.kotlin.takeIfNotBlank
import javax.inject.Inject

@HiltViewModel
class PromoOfferIapViewModel @Inject constructor(
    private val notifications: ApiNotificationManager,
    private val ensureIapOfferStillValid: EnsureIapOfferStillValid,
) : ViewModel() {

    data class OfferViewState(
        val imageUrlLight: String,
        val imageUrlDark: String,
        val imageContentDescription: String?,
        val buttonLabel: String?,
        val iapParams: NotificationIapParams,
        val notificationReference: String?,
        val upgradeTrigger: UpgradeTrigger,
    )

    suspend fun getOfferViewState(notificationId: String, width: Int): OfferViewState? {
        val notification = notifications.activeListFlow
            .first()
            .find { it.id == notificationId }
            ?: return null

        val offer = when {
            notification.type == ApiNotificationTypes.TYPE_ONE_TIME_IAP_POPUP -> {
                val panel = notification.offer?.panel
                getOfferViewState(
                    image = panel?.fullScreenImage,
                    width = width,
                    button = panel?.button,
                    iapParams = panel?.iapProductDetails?.google?.toIapParams(),
                    reference = notification.reference,
                    upgradeTrigger = UpgradeTrigger.PROMO_OFFER_POPUP,
                )
            }

            notification.type == ApiNotificationTypes.TYPE_HOME_SCREEN_BANNER &&
                ApiNotificationActions.isInAppPurchasePopup(notification.offer?.panel?.button?.action) -> {
                val panel = notification.offer?.panel?.button?.panel
                getOfferViewState(
                    image = panel?.fullScreenImage,
                    width = width,
                    button = panel?.button,
                    iapParams = panel?.iapProductDetails?.google?.toIapParams(),
                    reference = notification.reference,
                    upgradeTrigger = UpgradeTrigger.PROMO_OFFER_BANNER,
                )
            }

            else -> null
        }
        return offer
            ?.takeIf { ensureIapOfferStillValid(it.iapParams) }
    }

    private fun getOfferViewState(
        image: ApiNotificationOfferFullScreenImage?,
        width: Int,
        button: ApiNotificationOfferButton?,
        iapParams: NotificationIapParams?,
        reference: String?,
        upgradeTrigger: UpgradeTrigger,
    ): OfferViewState? {
        val imageSource = image?.let { PromoOfferImage.getFullScreenImage(width, image) }
        val imageContentDescription = image?.alternativeText
        return if (iapParams != null && imageSource?.url != null && imageSource.urlLight != null) {
            OfferViewState(
                imageUrlDark = imageSource.url,
                imageUrlLight = imageSource.urlLight,
                imageContentDescription = imageContentDescription,
                buttonLabel = button?.text?.takeIfNotBlank(),
                iapParams = iapParams,
                notificationReference = reference,
                upgradeTrigger = upgradeTrigger,
            )
        } else {
            null
        }
    }
}
